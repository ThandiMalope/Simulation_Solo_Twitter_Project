document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const main = document.querySelector('main');
  
    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const tweetText = document.querySelector('#tweet-text').value;
  
        const tweet = document.createElement('div');
        tweet.classList.add('tweet');
  
        const avatar = document.createElement('div');
        avatar.classList.add('avatar');
        const avatarImg = document.createElement('img');
        avatarImg.src = 'Assets/Avatar1.jpg'; // Assuming the path is correct
        avatarImg.alt = 'Avatar';
        avatar.appendChild(avatarImg);
  
        const tweetContent = document.createElement('div');
        tweetContent.classList.add('tweet-content');
  
        const username = document.createElement('span');
        username.classList.add('username');
        username.textContent = '@CoolCoder123';
  
        const tweetTextElement = document.createElement('p');
        tweetTextElement.classList.add('tweet-text');
        tweetTextElement.textContent = tweetText;
  
        const actions = document.createElement('div');
        actions.classList.add('actions');
  
        const likeButton = document.createElement('button');
        likeButton.classList.add('action-button');
        likeButton.textContent = 'Like';
  
        const repostButton = document.createElement('button');
        repostButton.classList.add('action-button');
        repostButton.textContent = 'Repost';
  
        actions.appendChild(likeButton);
        actions.appendChild(repostButton);
  
        tweetContent.appendChild(username);
        tweetContent.appendChild(tweetTextElement);
        tweetContent.appendChild(actions);
  
        tweet.appendChild(avatar);
        tweet.appendChild(tweetContent);
  
        main.insertBefore(tweet, main.firstChild);
  
        // Clear input after submitting
        document.querySelector('#tweet-text').value = '';
    });
});
